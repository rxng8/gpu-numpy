# %%

import gnp
gnp.__dir__()


